<link rel="stylesheet" type="text/css" href="<?php echo SITEROOTADMIN; ?>css/adminloginstyle.css"  />
<link rel="stylesheet" type="text/css" href="<?php echo SITEROOTADMIN; ?>css/css.css"  />
<link rel="stylesheet" type="text/css" href="<?php echo SITEROOTADMIN; ?>css/screen.css"  />
<link rel="stylesheet" type="text/css" href="<?php echo SITEROOTADMIN; ?>css/adminnav.css" media="screen">
<link  rel="stylesheet" type="text/css" href="<?php echo SITEROOTADMIN; ?>css/style.css" >
<link rel="stylesheet" type="text/css" href="<?php echo SITEROOTADMIN; ?>jquery_ui/jquery-ui.css"/>
<link  rel="stylesheet" href="<?php echo SITEROOTADMIN; ?>css/bootstrap.min.css">
<link  rel="stylesheet" href="<?php echo SITEROOTADMIN; ?>css/owl.carousel.css">
<link rel="stylesheet" href="//maxcdn.bootstrapcdn.com/font-awesome/4.3.0/css/font-awesome.min.css">
<link rel="stylesheet" href="<?php echo SITEROOT;?>jsvalidation/css/validationEngine.jquery.css" type="text/css"/>



<script src="https://code.jquery.com/jquery-1.11.2.js"></script>

<!-- ==============Animated Form Switching================= -->
<link rel="stylesheet" type="text/css" href="<?php echo SITEROOTADMIN; ?>css/animatedformcss.css">
<link  rel="stylesheet" type="text/css" href="<?php echo SITEROOTADMIN; ?>css/bootstrap.min.css">
<!-- javascript and jquery -->
<script src="<?php echo SITEROOTADMIN; ?>jscript/owl.carousel.min.js"></script>
<script src="<?php echo SITEROOTADMIN; ?>jquery_ui/jquery-ui.min.js"></script>
<script src="<?php echo SITEROOTADMIN; ?>jscript/bootstrap.min.js"></script>
<script type="text/javascript" src="<?php echo SITEROOTADMIN; ?>js/scripts.js"></script>

<!-- jquery for validation -->

<script src="<?php echo SITEROOT; ?>jsvalidation/languages/jquery.validationEngine-en.js" type="text/javascript" charset="utf-8"></script>  
<script src="<?php echo SITEROOT; ?>jsvalidation/jquery.validationEngine.js" type="text/javascript" charset="utf-8"></script>



<?php /*?><script type="text/javascript" src="<?php echo SITEROOT; ?>scripts/adminvalidation.js"></script>
<script type="text/javascript" src="<?php echo SITEROOT; ?>scripts/ajax.js"></script>
<link rel="stylesheet" href="<?php echo SITEROOT; ?>test/screen.css" type="text/css" media="screen" title="default" /><?php */?>

<?php /*<!-- jQuery Validation-->
<!--<link rel="stylesheet" type="text/css" href="<?php //echo SITEROOT;?>jquery/jquery.validate.css" />-->
<!--<script src="<?php //echo SITEROOT;?>jquery/jquery.validation.functions.js" type="text/javascript"></script>-->
<script src="<?php echo SITEROOT;?>jquery/jquery.validate.js" type="text/javascript"></script>
<script src="<?php echo SITEROOT;?>jquery/jquery.validate.min.js" type="text/javascript"></script>
<script src="<?php echo SITEROOT;?>jquery/additional-methods.js" type="text/javascript"></script>
<script src="<?php echo SITEROOT;?>jquery/additional-methods.min.js" type="text/javascript"></script>


<!-- jQuery Validation Ends Here -->*/?>